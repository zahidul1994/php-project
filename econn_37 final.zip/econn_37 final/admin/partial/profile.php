
<div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="../assets/img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4"><?php echo $userinfo['username'] ?></h1>
              <p>Zahidul islam</p>
            </div>
          </div>
          <span class="heading">Main Admin</span>