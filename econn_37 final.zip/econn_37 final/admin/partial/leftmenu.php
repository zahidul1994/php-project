<ul class="list-unstyled">
                    <li class=""><a href="../index.php"> <i class="icon-home"></i>Home </a></li>
                    <li><a href="category.php"> <i class="icon-interface-windows"></i>Category</a></li>
                    <li><a href="product.php"> <i class="icon-interface-windows"></i>Product</a></li>
                    <li><a href="manufacture.php"> <i class="icon-interface-windows"></i>Manufacture</a></li>
                    <li><a href="customer.php"> <i class="icon-interface-windows"></i>Customer</a></li>
                    <li><a href="orders.php"> <i class="icon-interface-windows"></i>Order</a></li>
          </ul><span class="heading">Extras</span>
          <ul class="list-unstyled">
            <li> <a href="promotion.php"> <i class="icon-flask"></i>Promotions</a></li>
            <li> <a href="hot.php"> <i class="icon-screen"></i>Hot Items </a></li>
            <li> <a href="carousel_images.php"> <i class="icon-mail"></i>Carousel Images </a></li>
            <li> <a href="view.php"> <i class="icon-picture"></i>Demo </a></li>
          </ul>
        </nav>
        <div class="content-inner">
          <!-- Page Header-->
          