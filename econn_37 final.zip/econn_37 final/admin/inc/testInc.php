<?php
namespace App\inc;
class testInc{
    public function test(){
        return "test function in testInc class";
    }
}