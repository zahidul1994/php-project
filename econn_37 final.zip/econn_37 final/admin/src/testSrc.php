<?php
namespace App\src;
class testSrc{
    public function test(){
        return "test function in testSrc class";
    }
}