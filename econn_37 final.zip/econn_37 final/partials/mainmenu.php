<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	        <ul class="nav navbar-nav">
			<li><a href="index.php">Home</a></li>
			<li><a href="products.php">Products</a></li>
		        <li class="dropdown">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Men <b class="caret"></b></a>
		            <ul class="dropdown-menu multi-column columns-3">
			            <div class="row">
				            <div class="col-sm-4">
					            <ul class="multi-column-dropdown">
									<h6>NEW IN</h6>
						            <li><a href="products.php">New In Clothing</a></li>
						            <li><a href="products.php">New In Bags</a></li>
						            <li><a href="products.php">New In Shoes</a></li>
						            <li><a href="products.php">New In Watches</a></li>
						            <li><a href="products.php">New In Grooming</a></li>
					            </ul>
				            </div>
				            <div class="col-sm-4">
					            <ul class="multi-column-dropdown">
									<h6>CLOTHING</h6>
						            <li><a href="products.php">Polos & Tees</a></li>
						            <li><a href="products.php">Casual Shirts</a></li>
						            <li><a href="products.php">Casual Trousers</a></li>
						            <li><a href="products.php">Jeans</a></li>
						            <li><a href="products.php">Shorts & 3/4th</a></li>
						            <li><a href="products.php">Formal Shirts</a></li>
						            <li><a href="products.php">Formal Trousers</a></li>
						            <li><a href="products.php">Suits & Blazers</a></li>
						            <li><a href="products.php">Track Wear</a></li>
						            <li><a href="products.php">Inner Wear</a></li>
					            </ul>
				            </div>
				            <div class="col-sm-4">
					            <ul class="multi-column-dropdown">
									<h6>WATCHES</h6>
						            <li><a href="products.php">Analog</a></li>
						            <li><a href="products.php">Chronograph</a></li>
						            <li><a href="products.php">Digital</a></li>
						            <li><a href="products.php">Watch Cases</a></li>
					            </ul>
				            </div>
							<div class="clearfix"></div>
			            </div>
		            </ul>
		        </li>
		        <li class="dropdown">
		            <a href="#" class="dropdown-toggle" data-toggle="dropdown">women <b class="caret"></b></a>
		            <ul class="dropdown-menu multi-column columns-3">
			            <div class="row">
				            <div class="col-sm-4">
					            <ul class="multi-column-dropdown">
									<h6>NEW IN</h6>
						            <li><a href="products.php">New In Clothing</a></li>
						            <li><a href="products.php">New In Bags</a></li>
						            <li><a href="products.php">New In Shoes</a></li>
						            <li><a href="products.php">New In Watches</a></li>
						            <li><a href="products.php">New In Beauty</a></li>
					            </ul>
				            </div>
				            <div class="col-sm-4">
					            <ul class="multi-column-dropdown">
									<h6>CLOTHING</h6>
						            <li><a href="products.php">Polos & Tees</a></li>
						            <li><a href="products.php">Casual Shirts</a></li>
						            <li><a href="products.php">Casual Trousers</a></li>
						            <li><a href="products.php">Jeans</a></li>
						            <li><a href="products.php">Shorts & 3/4th</a></li>
						            <li><a href="products.php">Formal Shirts</a></li>
						            <li><a href="products.php">Formal Trousers</a></li>
						            <li><a href="products.php">Suits & Blazers</a></li>
						            <li><a href="products.php">Track Wear</a></li>
						            <li><a href="products.php">Inner Wear</a></li>
					            </ul>
				            </div>
				            <div class="col-sm-4">
					            <ul class="multi-column-dropdown">
									<h6>WATCHES</h6>
						            <li><a href="products.php">Analog</a></li>
						            <li><a href="products.php">Chronograph</a></li>
						            <li><a href="products.php">Digital</a></li>
						            <li><a href="products.php">Watch Cases</a></li>
					            </ul>
				            </div>
							<div class="clearfix"></div>
			            </div>
		            </ul>
		        </li>
		        <li class="dropdown">
		        	<a href="#" class="dropdown-toggle" data-toggle="dropdown">kids <b class="caret"></b></a>
		            <ul class="dropdown-menu multi-column columns-2">
			            <div class="row">
				            <div class="col-sm-6">
					            <ul class="multi-column-dropdown">
									<h6>NEW IN</h6>
						            <li><a href="products.php">New In Boys Clothing</a></li>
						            <li><a href="products.php">New In Girls Clothing</a></li>
						            <li><a href="products.php">New In Boys Shoes</a></li>
						            <li><a href="products.php">New In Girls Shoes</a></li>
					            </ul>
				            </div>
				            <div class="col-sm-6">
					             <ul class="multi-column-dropdown">
									<h6>ACCESSORIES</h6>
						            <li><a href="products.php">Bags</a></li>
						            <li><a href="products.php">Watches</a></li>
						            <li><a href="products.php">Sun Glasses</a></li>
						            <li><a href="products.php">Jewellery</a></li>
					            </ul>
				            </div>
							<div class="clearfix"></div>
			            </div>
		            </ul>
		        </li>
					<li><a href="typography.html">TYPO</a></li>
					<li><a href="contact.php">CONTACT</a></li>
	        </ul>
	    </div>